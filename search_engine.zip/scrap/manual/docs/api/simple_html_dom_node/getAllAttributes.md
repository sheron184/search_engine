# getAllAttributes

```php
getAllAttributes ( ) : array
```

Returns all attributes for the current node.