This is a search engine build with web scrapping.
basically this will pulled data from google
I used simple-html-dom php library for this
I used ajax to call back end here there are more ways to do this as well.
I have explained the in source code.
Hope this helps.
Enjoy